<?php
session_start();
//كده عملت اتصال مع الملف اللي متوصل بالداتا بيز
require '../inc/db.php';

/*
      اللي ف صفحه التسجيل واعمل فلتر للبيانات اللي جايه submitهنا انا بتشيك ع زرار ال 

*/
if(isset($_POST['submit'])){
    /*
        للداتا جوه الداتابيز insertكده انا الدتا بتجيللي فاضل اني اعمل
     */
    $name= filter_var($_POST['name'],FILTER_SANITIZE_STRING);
    $email= filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);
    $mobile= filter_var($_POST['mobile'],FILTER_SANITIZE_STRING);
    $password=password_hash(filter_var($_POST['password'],FILTER_SANITIZE_STRING),PASSWORD_DEFAULT);

    //insert into DB
    $sql = "INSERT INTO users (name,email,mobile,password) VALUES (?,?,?,?)";
    //هنا انا بقوله نفذلي الجمله دي اللي هيا sql 
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$name,$email,$mobile,$password]);
        /* 
            بمعني ايه السطر ده ان الدتا خزنتها ف السيشن 
        */
    $_SESSION['success'] = "data inserted";

}
header("location:../register.php");
