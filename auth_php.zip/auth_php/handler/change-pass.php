<?php 
    session_start();
    require '../inc/db.php';
    if(isset($_POST['submit'])){
       
        $old_password =filter_var($_POST['old_password'],FILTER_SANITIZE_STRING);
        $new_password =filter_var($_POST['new_password'],FILTER_SANITIZE_STRING);
        $confirm_password =filter_var($_POST['confirm_password'],FILTER_SANITIZE_STRING);
        // هنا بقوله يشوف الايميل اللي اليوزر داخل بيه ف السيشن و يقارنه ب اللي ف الداتا بيز
        $sql="SELECT * FROM users WHERE email=? ";
        $stmt=$pdo->prepare($sql);
        $stmt->execute([$_SESSION['user_email']]);
        $data=$stmt->fetchobject();
        if($data)
        {
        
            $check = password_verify($old_password,$data->password);
            if($check)
            {
                //   هنا انا بشوف لو النيو باسورد بيساوي الكونفيرم ف بعمله هاش و كده تمام واروح اعمله ابديت ف الداتابيز
                if($new_password === $confirm_password)
                {
                    $new_password=password_hash($new_password,PASSWORD_DEFAULT);
                    $sql="UPDATE users SET Password=? WHERE email=? ";
                    $stmt=$pdo->prepare($sql);
                    $stmt->execute([$new_password,$_SESSION['user_email']]);
                    header("location:../show-data.php");
                    die();
                }
                else
                {
                    $_SESSION['error']= "Password Not The Same" ;
                }
             
            }
            else
            {
                $_SESSION['error'] = "Password Not Correct";

            }
        }
        else
        {
            $_SESSION['error'] = "Data Not Correct";
        }
        

    }
header("location:../change-pass.php");
?>