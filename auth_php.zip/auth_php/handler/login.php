<?php 
    session_start();
    require '../inc/db.php';
    if(isset($_POST['submit'])){
        /*
           login انا استخدم الايميل و الباسورد بس ف 
        */
        $email =filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);
        $password =filter_var($_POST['password'],FILTER_SANITIZE_STRING);
       
        //check if this email exists or not
        $sql="SELECT * FROM users WHERE email=?";
        $stmt=$pdo->prepare($sql);
        $stmt->execute([$email]);
        // بتعرفني فيه بيانات موجوده ولالا
        $data=$stmt->fetchobject();
        if($data)
        {
            /*
                الفانشكن دي بتاخد الباسورد اللي اليوزر هيدخله ف الوجان و تقارنه بالهاش 
            */
            $check = password_verify($password,$data->password);
            if($check)
            {
                $_SESSION['user_id'] = $data->id; 
                $_SESSION['user_name'] = $data->name; 
                $_SESSION['user_email'] = $data->email; 
                $_SESSION['user_mobile'] = $data->mobile; 
                //علشان ينقلني ع الصفحه دي اول لما اعمل لوجان
                header("location:../index.php");
                die();
            }
            else
            {
                $_SESSION['error'] = "Email or Password Not Correct";

            }
        }
        else
        {
            //عملت سيشن اسمه ايرور متخزن فيه ان الداتا غير صحيحه  
            $_SESSION['error'] = "Data Not Correct";
        }
        

    }
//علشان ينقلني ع الصفحه دي اول لما اعمل لوجان
header("location:../login.php");
?>