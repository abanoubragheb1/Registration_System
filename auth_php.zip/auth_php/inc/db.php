<?php

//connection
try{
    $dsn = "mysql:host=localhost;dbname=auth_php";
    $pdo = new PDO($dsn,"root","");
}
catch(PDOException $e){
    echo "Error ". $e->getMessage();
    die();

}




/*
    PDO == بيخليني اتعامل مع اكتر من نوع ف الداتا بيز
*/